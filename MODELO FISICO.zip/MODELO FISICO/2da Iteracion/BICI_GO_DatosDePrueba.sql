

INSERT INTO Departamento (Nombre) VALUES
('Magdalena'),
('Bogotá D.C.'),
('Antioquia'),
('Valle del Cauca'),
('Bolívar'),
('Quindío'),
('Caldas');


INSERT INTO Ciudad (Nombre, Departamento) VALUES
('Santa Marta', 1),
('Bogotá', 2),
('Medellín', 3),
('Cali', 4),
('Cartagena', 5),
('Armenia', 6),
('Manizales', 7);



INSERT INTO Contacto (Nombre, Telefono) VALUES
('María Fernanda Rodríguez', '3001234567'),
('Carlos Andrés Gómez', '3102345678'),
('Laura Sofía Martínez', '3203456789'),
('Juan Pablo Hernández', '3014567890'),
('Andrea Carolina López', '3115678901'),
('Diego Fernando Pérez', '3216789012'),
('Valentina Castro Ruiz', '3027890123'),
('Santiago Ramírez Torres', '3128901234');





INSERT INTO Horario (horario_Inicio, horario_Fin) VALUES
('08:00:00', '18:00:00'),
('07:00:00', '19:00:00'),
('06:00:00', '20:00:00'),
('09:00:00', '17:00:00'),
('08:00:00', '20:00:00');




INSERT INTO Servicios (Nombre, Estado, Descripcion) VALUES
('Alquiler de Bicicletas', 1, 'Servicio de alquiler de bicicletas de diferentes tipos'),
('Taller de Reparación', 1, 'Servicio de reparación y mantenimiento de bicicletas'),
('Venta de Accesorios', 1, 'Venta de cascos, candados, luces y otros accesorios'),
('Guías Turísticos', 1, 'Tours guiados por rutas turísticas'),
('Estación de Hidratación', 1, 'Punto de agua y bebidas para ciclistas'),
('Casilleros de Seguridad', 1, 'Guardado seguro de pertenencias'),
('Área de Descanso', 1, 'Zona de descanso con sillas y sombra');



INSERT INTO Punto_De_Alquiler (ciudad, Latitud, Longitud, Capacidad_Bicicletas, ID_Servicio, Horario, id_contacto, Fotos) VALUES
(1, 11.2403547, -74.2110227, 50, 1, 1, 1, 'https://bicigo.com/fotos/santa-marta-centro.jpg'),
(1, 11.2041758, -74.2276367, 30, 1, 2, 2, 'https://bicigo.com/fotos/rodadero.jpg'),
(2, 4.6945278, -74.0308333, 60, 1, 1, 3, 'https://bicigo.com/fotos/usaquen.jpg'),
(2, 4.5968889, -74.0758333, 45, 1, 1, 4, 'https://bicigo.com/fotos/candelaria.jpg'),
(3, 6.2086111, -75.5694444, 40, 1, 2, 5, 'https://bicigo.com/fotos/lleras.jpg'),
(3, 6.2447222, -75.5891667, 35, 1, 1, 6, 'https://bicigo.com/fotos/laureles.jpg'),
(4, 3.4516667, -76.5319444, 30, 1, 1, 7, 'https://bicigo.com/fotos/san-antonio.jpg'),
(5, 10.4213889, -75.5444444, 35, 1, 2, 8, 'https://bicigo.com/fotos/getsemani.jpg');



INSERT INTO Seguro (Aseguradora, fecha_Inicio, fecha_Fin) VALUES
('Seguros Colombia S.A.', '2024-01-01', '2025-12-31'),
('Liberty Seguros', '2024-01-01', '2025-12-31'),
('Mapfre Seguros', '2024-01-01', '2025-12-31'),
('Sura Seguros', '2024-01-01', '2025-12-31'),
('Allianz Seguros', '2024-01-01', '2025-12-31');



INSERT INTO estado_Bicicleta (Nombre, Descripcion) VALUES
('Excelente', 'Bicicleta en perfecto estado, recién revisada'),
('Bueno', 'Bicicleta en buen estado, funcionamiento normal'),
('Requiere Mantenimiento', 'Bicicleta funcional pero necesita revisión pronto'),
('En Mantenimiento', 'Bicicleta actualmente en taller'),
('Fuera de Servicio', 'Bicicleta no disponible temporalmente');



INSERT INTO Bicicleta (Id_PuntoAlquiler, Marca, Modelo, TamañoMarco, Kilometraje, año_Fabricacion, Horas_Uso, Estado, Seguro) VALUES
-- Santa Marta Centro 
(1, 'Trek', 'Marlin 7', 'M', 250.50, 2023, 45.5, 'Excelente', 1),
(1, 'Giant', 'Escape 3', 'L', 180.20, 2023, 32.0, 'Excelente', 1),
(1, 'Specialized', 'Rockhopper', 'M', 120.00, 2024, 28.5, 'Excelente', 2),
(1, 'Cannondale', 'Quick 4', 'S', 300.75, 2023, 55.2, 'Bueno', 1),
(1, 'Scott', 'Sub Cross', 'L', 95.30, 2024, 18.0, 'Excelente', 3),
(1, 'Merida', 'eScultura', 'M', 50.00, 2024, 12.5, 'Excelente', 4),

-- Rodadero 
(2, 'Giant', 'Simple Seven', 'M', 340.25, 2023, 62.0, 'Bueno', 1),
(2, 'Trek', 'Verve 2', 'S', 145.00, 2024, 28.5, 'Excelente', 1),
(2, 'Specialized', 'Roll', 'M', 280.60, 2023, 51.2, 'Bueno', 1),
(2, 'Electra', 'Townie', 'L', 98.30, 2024, 19.5, 'Excelente', 2),

-- Usaquén 
(3, 'Trek', 'Domane AL 2', 'M', 110.50, 2024, 22.0, 'Excelente', 3),
(3, 'Giant', 'Contend 3', 'L', 245.30, 2023, 48.5, 'Bueno', 3),
(3, 'Specialized', 'Allez', 'M', 78.20, 2024, 15.5, 'Excelente', 3),
(3, 'Cannondale', 'CAAD Optimo', 'S', 92.75, 2024, 18.2, 'Excelente', 3),

-- Candelaria (
(4, 'Giant', 'Escape 2', 'M', 135.40, 2024, 28.0, 'Excelente', 1),
(4, 'Trek', 'FX 3', 'L', 268.90, 2023, 52.5, 'Bueno', 1),
(4, 'Specialized', 'Sirrus 2.0', 'M', 95.20, 2024, 19.0, 'Excelente', 2),

-- Lleras 
(5, 'Trek', 'Dual Sport 3', 'M', 155.30, 2024, 30.5, 'Excelente', 1),
(5, 'Giant', 'Roam 2', 'L', 285.75, 2023, 55.0, 'Bueno', 1),
(5, 'Scott', 'Sub Sport 40', 'M', 112.40, 2024, 22.5, 'Excelente', 2),

-- Laureles 
(6, 'Specialized', 'Crosstrail', 'M', 112.40, 2024, 22.5, 'Excelente', 1),
(6, 'Trek', 'FX 2', 'L', 195.80, 2023, 38.2, 'Bueno', 1),

-- San Antonio 
(7, 'Scott', 'Sub Sport 30', 'M', 88.90, 2024, 17.8, 'Excelente', 1),
(7, 'Giant', 'Escape 1', 'L', 142.30, 2024, 28.5, 'Excelente', 2),

-- Getsemaní 
(8, 'Trek', '820', 'L', 325.60, 2023, 64.2, 'Bueno', 2),
(8, 'Giant', 'ATX 2', 'M', 145.20, 2024, 28.8, 'Excelente', 3);



INSERT INTO Tarifa (precio) VALUES
(8000),   -- Por hora
(35000),  -- Por día
(60000),  -- Fin de semana
(180000), -- Por semana
(600000), -- Por mes
(5500000);-- Por año



INSERT INTO Duracion (id_tarifas, fecha_inicio, fecha_fin) VALUES
(1, '2024-01-01 00:00:00', NULL),
(2, '2024-01-01 00:00:00', NULL),
(3, '2024-01-01 00:00:00', NULL),
(4, '2024-01-01 00:00:00', NULL),
(5, '2024-01-01 00:00:00', NULL),
(6, '2024-01-01 00:00:00', NULL);



INSERT INTO Beneficios_y_Condiciones (nombre, descripcion, politicas) VALUES
('Plan Por Hora', 'Ideal para recorridos cortos por la ciudad', 'Cancelación gratuita 30 minutos antes. No reembolsable después de iniciado.'),
('Plan Por Día', 'Perfecto para explorar durante todo el día', 'Cancelación gratuita hasta 2 horas antes. Reembolso del 50% después de 2 horas.'),
('Plan Fin de Semana', 'Disfruta todo el fin de semana en bicicleta', 'Cancelación gratuita hasta 24 horas antes. No reembolsable después.'),
('Plan Semanal', 'Una semana completa de aventuras', 'Cancelación gratuita hasta 48 horas antes. Reembolso parcial después.'),
('Plan Mensual', 'Para ciclistas frecuentes', 'Cancelación con 7 días de anticipación. Reembolso proporcional.'),
('Plan Anual', 'La opción más económica para uso constante', 'Cancelación con 30 días de anticipación. Reembolso proporcional según meses restantes.');




INSERT INTO Metodo_Pago (Nombre, Descripcion) VALUES
('Tarjeta Visa', 'Tarjetas de crédito y débito Visa'),
('Tarjeta Mastercard', 'Tarjetas de crédito y débito Mastercard'),
('Tarjeta Amex', 'Tarjetas American Express'),
('PayPal', 'Pago mediante cuenta PayPal'),
('Nequi', 'Billetera virtual Nequi'),
('Daviplata', 'Billetera virtual Daviplata'),
('Efectivo', 'Pago en efectivo en punto de alquiler'),
('PSE', 'Pagos Seguros en Línea - Transferencia bancaria');


INSERT INTO Pago (monto, metodo_Pago) VALUES
(35000, 'Tarjeta Visa'),
(35000, 'PayPal'),
(8000, 'Nequi'),
(180000, 'Tarjeta Visa'),
(35000, 'Efectivo'),
(60000, 'Tarjeta Mastercard'),
(600000, 'PSE'),
(8000, 'Daviplata'),
(35000, 'Tarjeta Amex'),
(180000, 'Tarjeta Visa');


INSERT INTO Usuario (nombre) VALUES
('Admin Principal BICI-GO'),
('Roberto Sánchez Moderador'),
('Juliana Ospina'),
('Miguel Ángel Torres'),
('Carolina Ruiz Méndez'),
('Andrés Felipe Díaz'),
('Natalia Jiménez Castro'),
('Fernando Castro López'),
('Isabella Vargas Mora'),
('Daniel Ramírez Pérez'),
('Gabriela Mendoza Silva'),
('Luis Fernando Parra'),
('Valentina Rojas Cruz'),
('Santiago Martínez Gil'),
('Camila Andrea Suárez');


-- Administrador
INSERT INTO Administrador (cedula) VALUES (1);

-- Moderador
INSERT INTO Moderador (cedula) VALUES (2);

-- Turistas
INSERT INTO Turista (cedula) VALUES 
(3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15);



INSERT INTO planes_de_alquirer (id_punto_alquiler, id_duracion, nombre, estado_plan, fecha_estado, id_factura, fecha) VALUES
(1, 1, 'Plan Por Hora', 1, '2024-01-01 00:00:00', 1, '2024-09-15 10:30:00'),
(1, 2, 'Plan Por Día', 1, '2024-01-01 00:00:00', 2, '2024-09-20 14:15:00'),
(2, 1, 'Plan Por Hora', 1, '2024-01-01 00:00:00', 3, '2024-09-25 16:20:00'),
(3, 4, 'Plan Semanal', 1, '2024-01-01 00:00:00', 4, '2024-10-01 08:30:00'),
(2, 2, 'Plan Por Día', 1, '2024-01-01 00:00:00', 5, '2024-10-03 15:45:00'),
(4, 3, 'Plan Fin de Semana', 1, '2024-01-01 00:00:00', 6, '2024-10-05 12:00:00'),
(5, 5, 'Plan Mensual', 1, '2024-01-01 00:00:00', 7, '2024-10-06 09:00:00'),
(1, 1, 'Plan Por Hora', 1, '2024-01-01 00:00:00', 8, '2024-10-07 17:30:00'),
(3, 2, 'Plan Por Día', 1, '2024-01-01 00:00:00', 9, '2024-10-08 11:00:00'),
(6, 4, 'Plan Semanal', 1, '2024-01-01 00:00:00', 10, '2024-10-09 14:20:00');



INSERT INTO Historial_de_alquiler (cedula, id_plan, fecha) VALUES
(3, 1, '2024-09-15 10:30:00'),
(4, 2, '2024-09-20 14:15:00'),
(5, 3, '2024-09-25 16:20:00'),
(6, 4, '2024-10-01 08:30:00'),
(7, 5, '2024-10-03 15:45:00'),
(8, 6, '2024-10-05 12:00:00'),
(9, 7, '2024-10-06 09:00:00'),
(10, 8, '2024-10-07 17:30:00'),
(11, 9, '2024-10-08 11:00:00'),
(12, 10, '2024-10-09 14:20:00');



INSERT INTO Reseña (cedula_usuario, titulo, calificacion, descripcion, fecha) VALUES
(3, 'Excelente experiencia en Santa Marta', 5, 'La bicicleta estaba en perfecto estado y el servicio fue excepcional. El personal muy amable y el recorrido por el centro histórico fue increíble.', '2024-09-16'),
(4, 'Muy buena bicicleta urbana', 4, 'La Giant Escape es muy cómoda para paseos por la ciudad. Todo estuvo muy bien, solo me hubiera gustado más información sobre rutas.', '2024-09-21'),
(5, 'Paseo corto pero agradable', 4, 'Buen servicio para paseos rápidos. La bicicleta funcionó perfecto y el proceso fue muy ágil.', '2024-09-26'),
(6, 'Semana fantástica en Bogotá', 5, 'El plan semanal fue ideal para explorar Bogotá a fondo. La bicicleta de ruta es excelente y el servicio de asistencia muy atento.', '2024-10-08'),
(7, 'Recomendado para familias', 5, 'Perfecto para paseos con niños. Las bicicletas están muy bien mantenidas y el personal es super amable.', '2024-10-04'),
(8, 'Buen fin de semana ciclístico', 4, 'Disfruté mucho el plan de fin de semana. La única sugerencia sería mejorar los mapas de rutas.', '2024-10-06'),
(9, 'Excelente para uso mensual', 5, 'El plan mensual es perfecto para ir al trabajo en bici. La relación calidad-precio es inmejorable.', '2024-10-07'),
(10, 'Rápido y eficiente', 5, 'El servicio por hora es perfecto para desplazamientos cortos. Todo muy profesional.', '2024-10-08');



INSERT INTO Multimedia (nombre, tipo, tamaño, id_reseña) VALUES
('santa_marta_centro_1.jpg', 'jpg', 2.5, 1),
('santa_marta_centro_2.jpg', 'jpg', 3.1, 1),
('santa_marta_centro_video.mp4', 'mp4', 45.8, 1),
('bogota_paseo_1.jpg', 'jpg', 2.8, 2),
('rodadero_playa.jpg', 'jpg', 3.3, 3),
('bogota_semana_1.jpg', 'jpg', 4.2, 4),
('bogota_semana_2.jpg', 'jpg', 3.9, 4),
('bogota_semana_video.mp4', 'mp4', 52.3, 4),
('familia_paseo.jpg', 'jpg', 3.5, 5),
('fin_semana_ruta.jpg', 'jpg', 2.9, 6),
('uso_mensual.jpg', 'jpg', 2.2, 7);




