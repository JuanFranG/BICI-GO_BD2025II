CREATE DATABASE BICI_GO_21
GO



CREATE TABLE Departamento (
    codigoDANE INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(100) NOT NULL
);


CREATE TABLE Ciudad (
    codigoDANE INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(100) NOT NULL,
    Departamento INT NOT NULL,
    FOREIGN KEY (Departamento) REFERENCES Departamento(codigoDANE)
);


CREATE TABLE Contacto (
    Cedula INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(150) NOT NULL,
    Telefono VARCHAR(20) NOT NULL
);

CREATE TABLE Horario (
    id_horario INT PRIMARY KEY IDENTITY(1,1),
    horario_Inicio TIME NOT NULL,
    horario_Fin TIME NOT NULL
);


CREATE TABLE Servicios (
    id_servicios INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(100) NOT NULL,
    Estado BIT NOT NULL DEFAULT 1,
    Descripcion TEXT NULL
);


CREATE TABLE Punto_De_Alquiler (
    ID_PuntoAlquier INT PRIMARY KEY IDENTITY(1,1),
    ciudad INT NOT NULL,
    Latitud DECIMAL(10, 8) NULL,
    Longitud DECIMAL(11, 8) NULL,
    Capacidad_Bicicletas INT NOT NULL,
    ID_Servicio INT NULL,
    Horario INT NULL,
    id_contacto INT NOT NULL,
    Fotos TEXT NULL,
    FOREIGN KEY (ciudad) REFERENCES Ciudad(codigoDANE),
    FOREIGN KEY (ID_Servicio) REFERENCES Servicios(id_servicios),
    FOREIGN KEY (Horario) REFERENCES Horario(id_horario),
    FOREIGN KEY (id_contacto) REFERENCES Contacto(Cedula)
);


CREATE TABLE Seguro (
    Numero_Poliza INT PRIMARY KEY IDENTITY(1,1),
    Aseguradora VARCHAR(100) NOT NULL,
    fecha_Inicio DATE NOT NULL,
    fecha_Fin DATE NOT NULL
);


CREATE TABLE estado_Bicicleta (
    Nombre VARCHAR(50) PRIMARY KEY,
    Descripcion TEXT NULL
);


CREATE TABLE Bicicleta (
    id_bicicleta INT PRIMARY KEY IDENTITY(1,1),
    Id_PuntoAlquiler INT NOT NULL,
    Marca VARCHAR(50) NOT NULL,
    Modelo VARCHAR(50) NOT NULL,
    Tama�oMarco VARCHAR(10) NULL,
    Kilometraje DECIMAL(10, 2) DEFAULT 0,
    a�o_Fabricacion INT NULL,
    Horas_Uso DECIMAL(10, 2) DEFAULT 0,
    Estado VARCHAR(50) NOT NULL,
    Seguro INT NULL,
    FOREIGN KEY (Id_PuntoAlquiler) REFERENCES Punto_De_Alquiler(ID_PuntoAlquier),
    FOREIGN KEY (Estado) REFERENCES estado_Bicicleta(Nombre),
    FOREIGN KEY (Seguro) REFERENCES Seguro(Numero_Poliza)
);


CREATE TABLE Tarifa (
    id_tarifa INT PRIMARY KEY IDENTITY(1,1),
    precio DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Duracion (
    id_duracion INT PRIMARY KEY IDENTITY(1,1),
    id_tarifas INT NOT NULL,
    fecha_inicio DATETIME NOT NULL,
    fecha_fin DATETIME NULL,
    FOREIGN KEY (id_tarifas) REFERENCES Tarifa(id_tarifa)
);


CREATE TABLE Beneficios_y_Condiciones (
    nombre VARCHAR(100) PRIMARY KEY,
    descripcion TEXT NULL,
    politicas TEXT NULL
);


CREATE TABLE Metodo_Pago (
    Nombre VARCHAR(50) PRIMARY KEY,
    Descripcion VARCHAR(255) NULL
);


CREATE TABLE Pago (
    id_Factura INT PRIMARY KEY IDENTITY(1,1),
    monto DECIMAL(10, 2) NOT NULL,
    metodo_Pago VARCHAR(50) NOT NULL,
    FOREIGN KEY (metodo_Pago) REFERENCES Metodo_Pago(Nombre)
);


CREATE TABLE Usuario (
    Cedula INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(150) NOT NULL
);


CREATE TABLE Administrador (
    cedula INT PRIMARY KEY,
    FOREIGN KEY (cedula) REFERENCES Usuario(Cedula)
);


CREATE TABLE Moderador (
    cedula INT PRIMARY KEY,
    FOREIGN KEY (cedula) REFERENCES Usuario(Cedula)
);


CREATE TABLE Turista (
    cedula INT PRIMARY KEY,
    FOREIGN KEY (cedula) REFERENCES Usuario(Cedula)
);

CREATE TABLE planes_de_alquirer (
    id_plan INT PRIMARY KEY IDENTITY(1,1),
    id_punto_alquiler INT NOT NULL,
    id_duracion INT NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    estado_plan BIT NOT NULL DEFAULT 1,
    fecha_estado DATETIME DEFAULT GETDATE(),
    id_factura INT NULL,
    fecha DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (id_punto_alquiler) REFERENCES Punto_De_Alquiler(ID_PuntoAlquier),
    FOREIGN KEY (id_duracion) REFERENCES Duracion(id_duracion),
    FOREIGN KEY (nombre) REFERENCES Beneficios_y_Condiciones(nombre),
    FOREIGN KEY (id_factura) REFERENCES Pago(id_Factura)
);


CREATE TABLE Historial_de_alquiler (
    id_alquiler INT PRIMARY KEY IDENTITY(1,1),
    cedula INT NOT NULL,
    id_plan INT NOT NULL,
    fecha DATETIME NOT NULL UNIQUE,
    FOREIGN KEY (cedula) REFERENCES Usuario(Cedula),
    FOREIGN KEY (id_plan) REFERENCES planes_de_alquirer(id_plan)
);


CREATE TABLE Rese�a (
    id_rese�a INT PRIMARY KEY IDENTITY(1,1),
    cedula_usuario INT NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    calificacion INT NOT NULL CHECK (calificacion >= 1 AND calificacion <= 5),
    descripcion TEXT NULL,
    fecha DATE NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (cedula_usuario) REFERENCES Usuario(Cedula)
);


CREATE TABLE Multimedia (
    id_multimedia INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100) NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    tama�o DECIMAL(10, 2) NOT NULL,
    id_rese�a INT NOT NULL,
    FOREIGN KEY (id_rese�a) REFERENCES Rese�a(id_rese�a)
);


