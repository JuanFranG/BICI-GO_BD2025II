


--  Departamento, Ciudad y Punto


SELECT 
    d.Nombre AS Departamento,
    c.Nombre AS Ciudad,
    pa.ID_PuntoAlquier,
    pa.Capacidad_Bicicletas,
    pa.Latitud,
    pa.Longitud
FROM Departamento d
INNER JOIN Ciudad c ON d.codigoDANE = c.Departamento
INNER JOIN Punto_De_Alquiler pa ON c.codigoDANE = pa.ciudad
ORDER BY d.Nombre, c.Nombre;


-- PUNTOS DE ALQUILER Y SU INFORMACIÓN


SELECT 
    pa.ID_PuntoAlquier,
    c.Nombre AS Ciudad,
    d.Nombre AS Departamento,
    pa.Capacidad_Bicicletas,
    cnt.Nombre AS Contacto,
    cnt.Telefono,
    s.Nombre AS Servicio,
    h.horario_Inicio,
    h.horario_Fin
FROM Punto_De_Alquiler pa
INNER JOIN Ciudad c ON pa.ciudad = c.codigoDANE
INNER JOIN Departamento d ON c.Departamento = d.codigoDANE
INNER JOIN Contacto cnt ON pa.id_contacto = cnt.Cedula
LEFT JOIN Servicios s ON pa.ID_Servicio = s.id_servicios
LEFT JOIN Horario h ON pa.Horario = h.id_horario
ORDER BY pa.ID_PuntoAlquier;


-- INVENTARIO COMPLETO DE BICICLETAS POR PUNTO


SELECT 
    pa.ID_PuntoAlquier,
    c.Nombre AS Ciudad,
    COUNT(b.id_bicicleta) AS Total_Bicicletas,
    pa.Capacidad_Bicicletas,
    pa.Capacidad_Bicicletas - COUNT(b.id_bicicleta) AS Espacios_Disponibles,
    CAST(COUNT(b.id_bicicleta) * 100.0 / pa.Capacidad_Bicicletas AS DECIMAL(5,2)) AS Porcentaje_Ocupacion
FROM Punto_De_Alquiler pa
INNER JOIN Ciudad c ON pa.ciudad = c.codigoDANE
LEFT JOIN Bicicleta b ON pa.ID_PuntoAlquier = b.Id_PuntoAlquiler
GROUP BY pa.ID_PuntoAlquier, c.Nombre, pa.Capacidad_Bicicletas
ORDER BY Porcentaje_Ocupacion DESC;

-- BICICLETAS CON TODA SU INFORMACIÓN


SELECT 
    b.id_bicicleta,
    b.Marca,
    b.Modelo,
    b.TamañoMarco,
    b.año_Fabricacion,
    b.Kilometraje,
    b.Horas_Uso,
    b.Estado,
    eb.Descripcion AS Estado_Descripcion,
    pa.ID_PuntoAlquier AS Punto_Alquiler,
    c.Nombre AS Ciudad,
    s.Aseguradora,
    s.Numero_Poliza
FROM Bicicleta b
INNER JOIN estado_Bicicleta eb ON b.Estado = eb.Nombre
INNER JOIN Punto_De_Alquiler pa ON b.Id_PuntoAlquiler = pa.ID_PuntoAlquier
INNER JOIN Ciudad c ON pa.ciudad = c.codigoDANE
LEFT JOIN Seguro s ON b.Seguro = s.Numero_Poliza
ORDER BY b.id_bicicleta;


-- BICICLETAS POR ESTADO


SELECT 
    eb.Nombre AS Estado,
    COUNT(b.id_bicicleta) AS Total_Bicicletas,
    AVG(b.Kilometraje) AS Kilometraje_Promedio,
    AVG(b.Horas_Uso) AS Horas_Promedio
FROM estado_Bicicleta eb
LEFT JOIN Bicicleta b ON eb.Nombre = b.Estado
GROUP BY eb.Nombre
ORDER BY Total_Bicicletas DESC;

-- BICICLETAS QUE REQUIEREN MANTENIMIENTO (>250km o >50h)


SELECT 
    b.id_bicicleta,
    b.Marca,
    b.Modelo,
    b.Kilometraje,
    b.Horas_Uso,
    b.Estado,
    c.Nombre AS Ciudad
FROM Bicicleta b
INNER JOIN Punto_De_Alquiler pa ON b.Id_PuntoAlquiler = pa.ID_PuntoAlquier
INNER JOIN Ciudad c ON pa.ciudad = c.codigoDANE
WHERE b.Kilometraje > 250 OR b.Horas_Uso > 50
ORDER BY b.Kilometraje DESC;



-- USUARIOS POR ROL


SELECT 
    'Administrador' AS Rol,
    COUNT(a.cedula) AS Total
FROM Administrador a
UNION ALL
SELECT 
    'Moderador',
    COUNT(m.cedula)
FROM Moderador m
UNION ALL
SELECT 
    'Turista',
    COUNT(t.cedula)
FROM Turista t;

-- LISTADO COMPLETO DE USUARIOS CON SU ROL


SELECT 
    u.Cedula,
    u.nombre,
    CASE 
        WHEN a.cedula IS NOT NULL THEN 'Administrador'
        WHEN m.cedula IS NOT NULL THEN 'Moderador'
        WHEN t.cedula IS NOT NULL THEN 'Turista'
        ELSE 'Sin Rol'
    END AS Rol
FROM Usuario u
LEFT JOIN Administrador a ON u.Cedula = a.cedula
LEFT JOIN Moderador m ON u.Cedula = m.cedula
LEFT JOIN Turista t ON u.Cedula = t.cedula
ORDER BY 
    CASE 
        WHEN a.cedula IS NOT NULL THEN 1
        WHEN m.cedula IS NOT NULL THEN 2
        WHEN t.cedula IS NOT NULL THEN 3
        ELSE 4
    END,
    u.nombre;




-- PLANES DE ALQUILER CON TARIFAS Y BENEFICIOS
SELECT 
    p.id_plan,
    p.nombre AS Planes,
    bc.descripcion AS Descripcion_Plan,
    t.precio AS Tarifa,
    d.fecha_inicio AS Vigencia_Desde,
    d.fecha_fin AS Vigencia_Hasta,
    CASE WHEN p.estado_plan = 1 THEN 'Activo' ELSE 'Inactivo' END AS Estado,
    pa.ID_PuntoAlquier AS Punto_Alquiler,
    c.Nombre AS Ciudad
FROM planes_de_alquirer p
INNER JOIN Beneficios_y_Condiciones bc ON p.nombre = bc.nombre
INNER JOIN Duracion d ON p.id_duracion = d.id_duracion
INNER JOIN Tarifa t ON d.id_tarifas = t.id_tarifa
INNER JOIN Punto_De_Alquiler pa ON p.id_punto_alquiler = pa.ID_PuntoAlquier
INNER JOIN Ciudad c ON pa.ciudad = c.codigoDANE
ORDER BY t.precio;

-- PAGOS CON MÉTODO DE PAGO


SELECT 
    pg.id_Factura,
    pg.monto,
    mp.Nombre AS Metodo_Pago,
    mp.Descripcion AS Descripcion_Metodo
FROM Pago pg
INNER JOIN Metodo_Pago mp ON pg.metodo_Pago = mp.Nombre
ORDER BY pg.id_Factura;


-- ESTADÍSTICAS DE PAGOS POR MÉTODO


SELECT 
    mp.Nombre AS Metodo_Pago,
    COUNT(pg.id_Factura) AS Total_Transacciones,
    SUM(pg.monto) AS Monto_Total,
    AVG(pg.monto) AS Monto_Promedio,
    MIN(pg.monto) AS Monto_Minimo,
    MAX(pg.monto) AS Monto_Maximo
FROM Metodo_Pago mp
LEFT JOIN Pago pg ON mp.Nombre = pg.metodo_Pago
GROUP BY mp.Nombre
ORDER BY Total_Transacciones DESC;


-- HISTORIAL COMPLETO DE ALQUILERES

SELECT 
    h.id_alquiler,
    u.nombre AS Usuario,
    p.nombre AS Planes,
    pa.ID_PuntoAlquier AS Punto,
    c.Nombre AS Ciudad,
    pg.monto AS Monto_Pagado,
    mp.Nombre AS Metodo_Pago,
    h.fecha AS Fecha_Alquiler
FROM Historial_de_alquiler h
INNER JOIN Usuario u ON h.cedula = u.Cedula
INNER JOIN planes_de_alquirer p ON h.id_plan = p.id_plan
INNER JOIN Punto_De_Alquiler pa ON p.id_punto_alquiler = pa.ID_PuntoAlquier
INNER JOIN Ciudad c ON pa.ciudad = c.codigoDANE
LEFT JOIN Pago pg ON p.id_factura = pg.id_Factura
LEFT JOIN Metodo_Pago mp ON pg.metodo_Pago = mp.Nombre
ORDER BY h.fecha DESC;

--USUARIOS MÁS ACTIVOS (TOP 5)

SELECT TOP 5
    u.nombre AS Usuario,
    COUNT(h.id_alquiler) AS Total_Alquileres,
    SUM(pg.monto) AS Gasto_Total,
    AVG(pg.monto) AS Gasto_Promedio
FROM Usuario u
INNER JOIN Historial_de_alquiler h ON u.Cedula = h.cedula
INNER JOIN planes_de_alquirer p ON h.id_plan = p.id_plan
LEFT JOIN Pago pg ON p.id_factura = pg.id_Factura
GROUP BY u.nombre
ORDER BY Total_Alquileres DESC;

-- PLANES MÁS POPULARES


SELECT 
    p.nombre AS Planes,
    COUNT(h.id_alquiler) AS Veces_Contratado,
    SUM(pg.monto) AS Ingresos_Generados,
    AVG(pg.monto) AS Ingreso_Promedio
FROM planes_de_alquirer p
LEFT JOIN Historial_de_alquiler h ON p.id_plan = h.id_plan
LEFT JOIN Pago pg ON p.id_factura = pg.id_Factura
GROUP BY p.nombre
ORDER BY Veces_Contratado DESC;




-- RESEÑAS CON INFORMACIÓN DEL USUARIO


SELECT
    r.id_reseña,
    u.nombre AS Usuario,
    r.titulo,
    r.calificacion,
    MAX(CAST(r.descripcion AS VARCHAR(MAX))) AS descripcion,
    r.fecha,
    COUNT(m.id_multimedia) AS Archivos_Multimedia
FROM Reseña r
JOIN Usuario u   ON r.cedula_usuario = u.Cedula
LEFT JOIN Multimedia m ON r.id_reseña = m.id_reseña
GROUP BY 
    r.id_reseña, u.nombre, r.titulo, r.calificacion, r.fecha
ORDER BY r.fecha DESC;


-- DISTRIBUCIÓN DE CALIFICACIONES

SELECT 
    r.calificacion AS Estrellas,
    COUNT(*) AS Cantidad,
    CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Reseña) AS DECIMAL(5,2)) AS Porcentaje
FROM Reseña r
GROUP BY r.calificacion
ORDER BY r.calificacion DESC;

--CALIFICACIÓN PROMEDIO GENERAL


SELECT 
    AVG(CAST(calificacion AS FLOAT)) AS Calificacion_Promedio,
    COUNT(*) AS Total_Reseñas,
    MAX(calificacion) AS Mejor_Calificacion,
    MIN(calificacion) AS Peor_Calificacion
FROM Reseña;


 --MULTIMEDIA POR TIPO


SELECT 
    m.tipo AS Tipo_Archivo,
    COUNT(*) AS Total_Archivos,
    AVG(m.tamaño) AS Tamaño_Promedio_MB,
    SUM(m.tamaño) AS Tamaño_Total_MB
FROM Multimedia m
GROUP BY m.tipo
ORDER BY Total_Archivos DESC;


-- Bicicletas sin Punto de Alquiler


SELECT 
    COUNT(*) AS Total_Sin_Punto,
    CASE 
        WHEN COUNT(*) = 0 THEN ' Todas las bicicletas tienen punto asignado'
        ELSE ' ERROR: Hay bicicletas sin punto de alquiler'
    END AS Estado
FROM Bicicleta b
WHERE b.Id_PuntoAlquiler IS NULL;


-- VERIFICAR INTEGRIDAD: Planes sin Pago

SELECT 
    COUNT(*) AS Total_Sin_Pago,
    CASE 
        WHEN COUNT(*) = 0 THEN '  Todos los planes tienen pago'
        ELSE ' Hay planes sin pago asociado '
    END AS Estado
FROM planes_de_alquirer p
WHERE p.id_factura IS NULL;


--  Usuarios sin Rol

SELECT 
  u.Cedula,
  u.nombre,
  CASE 
    WHEN EXISTS (SELECT 1 FROM Administrador a WHERE a.cedula = u.Cedula)
      OR EXISTS (SELECT 1 FROM Moderador   m WHERE m.cedula = u.Cedula)
      OR EXISTS (SELECT 1 FROM Turista     t WHERE t.cedula = u.Cedula)
    THEN 'Con Rol' ELSE 'Sin Rol'
  END AS Estado_Rol
FROM Usuario u;





-- CIUDADES CON MÁS ACTIVIDAD


SELECT 
    c.Nombre AS Ciudad,
    COUNT(DISTINCT pa.ID_PuntoAlquier) AS Puntos_Alquiler,
    COUNT(DISTINCT b.id_bicicleta) AS Total_Bicicletas,
    COUNT(DISTINCT h.id_alquiler) AS Total_Alquileres
FROM Ciudad c
LEFT JOIN Punto_De_Alquiler pa ON c.codigoDANE = pa.ciudad
LEFT JOIN Bicicleta b ON pa.ID_PuntoAlquier = b.Id_PuntoAlquiler
LEFT JOIN planes_de_alquirer p ON pa.ID_PuntoAlquier = p.id_punto_alquiler
LEFT JOIN Historial_de_alquiler h ON p.id_plan = h.id_plan
GROUP BY c.Nombre
ORDER BY Total_Alquileres DESC;


-- MARCAS DE BICICLETAS MÁS POPULARES


SELECT 
    b.Marca,
    COUNT(*) AS Total_Bicicletas,
    AVG(b.Kilometraje) AS Kilometraje_Promedio,
    AVG(b.Horas_Uso) AS Horas_Uso_Promedio
FROM Bicicleta b
GROUP BY b.Marca
ORDER BY Total_Bicicletas DESC;


