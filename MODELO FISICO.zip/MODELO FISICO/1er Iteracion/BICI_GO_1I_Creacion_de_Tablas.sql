


-- Ciudad
CREATE TABLE ciudad (
    id_ciudad INT PRIMARY KEY IDENTITY(1,1),
    codigo_dane VARCHAR(10) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    departamento VARCHAR(100) NOT NULL
);

-- Punto de Alquiler
CREATE TABLE punto_de_alquiler (
    id_punto_de_alquiler INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(150) NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    latitud DECIMAL(10, 8),
    longitud DECIMAL(11, 8),
    capacidad_bicicletas INT NOT NULL,
    id_ciudad INT NOT NULL,
    FOREIGN KEY (id_ciudad) REFERENCES ciudad(id_ciudad)
);

-- Contacto
CREATE TABLE contacto (
    id_contacto INT PRIMARY KEY IDENTITY(1,1),
    nombre_completo VARCHAR(150) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    id_punto_de_alquiler INT NOT NULL,
    FOREIGN KEY (id_punto_de_alquiler) REFERENCES punto_de_alquiler(id_punto_de_alquiler)
);

-- Horario
CREATE TABLE horario (
    id_horario INT PRIMARY KEY IDENTITY(1,1),
    dia_semana VARCHAR(20) NOT NULL,
    hora_apertura TIME NOT NULL,
    hora_cierre TIME NOT NULL,
    id_punto_de_alquiler INT NOT NULL,
    FOREIGN KEY (id_punto_de_alquiler) REFERENCES punto_de_alquiler(id_punto_de_alquiler)
);

-- Servicios
CREATE TABLE servicios (
    id_servicios INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(500),
    estado BIT DEFAULT 1,
    id_punto_de_alquiler INT NOT NULL,
    FOREIGN KEY (id_punto_de_alquiler) REFERENCES punto_de_alquiler(id_punto_de_alquiler)
);

-- Seguro
CREATE TABLE seguro (
    id_seguro INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100) NOT NULL,
    numero_de_poliza VARCHAR(50) NOT NULL,
    aseguradora VARCHAR(100) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL
);

-- Tipo de Estado Bicicleta
CREATE TABLE tipo_de_estado_bicicleta (
    id_tipo_de_estado_bicicleta INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255)
);

-- Bicicletas
CREATE TABLE bicicletas (
    id_bicicletas INT PRIMARY KEY IDENTITY(1,1),
    codigo VARCHAR(50) NOT NULL UNIQUE,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    anio_fabricacion INT,
    tamanio_marco VARCHAR(20),
    tipo_uso VARCHAR(20),
    tipo_asistencia VARCHAR(20),
    kilometraje DECIMAL(10, 2) DEFAULT 0,
    necesita_mantenimiento VARCHAR(20),
    tarifa_base DECIMAL(10, 2),
    id_punto_de_alquiler INT,
    id_tipo_de_estado_bicicleta INT NOT NULL,
    id_seguro INT,
    FOREIGN KEY (id_punto_de_alquiler) REFERENCES punto_de_alquiler(id_punto_de_alquiler),
    FOREIGN KEY (id_tipo_de_estado_bicicleta) REFERENCES tipo_de_estado_bicicleta(id_tipo_de_estado_bicicleta),
    FOREIGN KEY (id_seguro) REFERENCES seguro(id_seguro)
);

-- Usuario
CREATE TABLE usuario (
    id_usuario INT PRIMARY KEY IDENTITY(1,1),
    nombre_completo VARCHAR(150) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    fecha_nacimiento DATE,
    fecha_registro DATETIME DEFAULT GETDATE()
);

-- Fotos (relacionada con usuario)
CREATE TABLE fotos (
    id_fotos INT PRIMARY KEY IDENTITY(1,1),
    url VARCHAR(500) NOT NULL,
    descripcion VARCHAR(255),
    id_usuario INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

-- Turista
CREATE TABLE turista (
    id_turista INT PRIMARY KEY IDENTITY(1,1),
    idioma_preferencia VARCHAR(20),
    zona_horaria VARCHAR(50),
    id_usuario INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

-- Administrador
CREATE TABLE administrador (
    id_administrador INT PRIMARY KEY IDENTITY(1,1),
    nivel_acceso VARCHAR(20),
    id_usuario INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

-- Moderador
CREATE TABLE moderador (
    id_moderador INT PRIMARY KEY IDENTITY(1,1),
    area_moderacion VARCHAR(50),
    id_usuario INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

-- Planes de Alquiler
CREATE TABLE planes_de_alquiler (
    id_planes_de_alquiler INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(500),
    estado_plan BIT DEFAULT 1
);

-- Duración
CREATE TABLE duracion (
    id_duracion INT PRIMARY KEY IDENTITY(1,1),
    tipo_duracion VARCHAR(20),
    cantidad INT,
    id_planes_de_alquiler INT NOT NULL,
    FOREIGN KEY (id_planes_de_alquiler) REFERENCES planes_de_alquiler(id_planes_de_alquiler)
);

-- Tarifas
CREATE TABLE tarifas (
    id_tarifas INT PRIMARY KEY IDENTITY(1,1),
    monto DECIMAL(10, 2) NOT NULL,
    moneda VARCHAR(10),
    fecha_inicio DATE,
    fecha_fin DATE,
    id_duracion INT NOT NULL,
    FOREIGN KEY (id_duracion) REFERENCES duracion(id_duracion)
);

-- Tipo de Método de Pago
CREATE TABLE tipo_de_metodo_de_pago (
    id_tipo_pago INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255)
);

-- Pago
CREATE TABLE pago (
    id_pago INT PRIMARY KEY IDENTITY(1,1),
    monto DECIMAL(10, 2) NOT NULL,
    fecha_pago DATETIME DEFAULT GETDATE(),
    estado VARCHAR(20),
    id_planes_de_alquiler INT NOT NULL,
    id_tipo_pago INT NOT NULL,
    FOREIGN KEY (id_planes_de_alquiler) REFERENCES planes_de_alquiler(id_planes_de_alquiler),
    FOREIGN KEY (id_tipo_pago) REFERENCES tipo_de_metodo_de_pago(id_tipo_pago)
);

-- Tipo de Beneficio
CREATE TABLE tipo_de_beneficio (
    id_tipo_beneficio INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(500)
);

-- Beneficios
CREATE TABLE beneficios (
    id_beneficios INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100),
    detalle VARCHAR(500),
    id_planes_de_alquiler INT NOT NULL,
    id_tipo_beneficio INT NOT NULL,
    FOREIGN KEY (id_planes_de_alquiler) REFERENCES planes_de_alquiler(id_planes_de_alquiler),
    FOREIGN KEY (id_tipo_beneficio) REFERENCES tipo_de_beneficio(id_tipo_beneficio)
);

-- Etiquetas
CREATE TABLE etiquetas (
    id_etiquetas INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(50) NOT NULL,
    categoria VARCHAR(50)
);

-- Historial de Alquiler
CREATE TABLE historial_de_alquiler (
    id_historial INT PRIMARY KEY IDENTITY(1,1),
    fecha_inicio DATETIME NOT NULL,
    fecha_fin DATETIME,
    kilometros_recorridos DECIMAL(10, 2),
    costo_total DECIMAL(10, 2),
    id_usuario INT NOT NULL,
    id_bicicletas INT NOT NULL,
    id_planes_de_alquiler INT NOT NULL,
    id_etiqueta INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_bicicletas) REFERENCES bicicletas(id_bicicletas),
    FOREIGN KEY (id_planes_de_alquiler) REFERENCES planes_de_alquiler(id_planes_de_alquiler),
    FOREIGN KEY (id_etiqueta) REFERENCES etiquetas(id_etiquetas)
);

-- Reseña
CREATE TABLE reseña (
    id_reseña INT PRIMARY KEY IDENTITY(1,1),
    titulo VARCHAR(150) NOT NULL,
    calificacion DECIMAL(2, 1) NOT NULL,
    descripcion TEXT,
    fecha_creacion DATETIME DEFAULT GETDATE(),
    id_usuario INT NOT NULL,
    id_etiqueta INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_etiqueta) REFERENCES etiquetas(id_etiquetas)
);

-- Tipo de Multimedia
CREATE TABLE tipo_de_multimedia (
    id_tipo_de_multimedia INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(20) NOT NULL,
    extension VARCHAR(10),
    tamaño INT,
    hipervinculo VARCHAR(500)
);

-- Multimedia
CREATE TABLE multimedia (
    id_multimedia INT PRIMARY KEY IDENTITY(1,1),
    url VARCHAR(500) NOT NULL,
    fecha_subida DATETIME DEFAULT GETDATE(),
    fecha_aprobacion DATETIME,
    id_reseña INT NOT NULL,
    id_tipo_de_multimedia INT NOT NULL,
    FOREIGN KEY (id_reseña) REFERENCES reseña(id_reseña),
    FOREIGN KEY (id_tipo_de_multimedia) REFERENCES tipo_de_multimedia(id_tipo_de_multimedia)
);


