

INSERT INTO ciudad (codigo_dane, nombre, departamento) VALUES
('47001', 'Santa Marta', 'Magdalena'),
('11001', 'Bogotá', 'Bogotá D.C.'),
('05001', 'Medellín', 'Antioquia'),
('76001', 'Cali', 'Valle del Cauca'),
('13001', 'Cartagena', 'Bolívar');


INSERT INTO punto_de_alquiler (nombre, direccion, latitud, longitud, capacidad_bicicletas, id_ciudad) VALUES
('BICI-GO Centro Santa Marta', 'Carrera 3 # 16-34', 11.2403547, -74.2110227, 50, 1),
('BICI-GO Rodadero', 'Carrera 1 # 18-20', 11.2041758, -74.2276367, 30, 1),
('BICI-GO Usaquén', 'Calle 119 # 6-20', 4.6945278, -74.0308333, 60, 2),
('BICI-GO Lleras', 'Carrera 37 # 8-20', 6.2086111, -75.5694444, 40, 3),
('BICI-GO San Antonio', 'Calle 5 # 6-23', 3.4516667, -76.5319444, 30, 4);


INSERT INTO contacto (nombre_completo, telefono, id_punto_de_alquiler) VALUES
('María Rodríguez', '+57 300 123 4567', 1),
('Carlos Gómez', '+57 310 234 5678', 2),
('Juan Hernández', '+57 301 456 7890', 3),
('Diego Pérez', '+57 321 678 9012', 4),
('Santiago Ramírez', '+57 312 890 1234', 5);


INSERT INTO horario (dia_semana, hora_apertura, hora_cierre, id_punto_de_alquiler) VALUES
('Lunes', '08:00', '18:00', 1),
('Martes', '08:00', '18:00', 1),
('Miércoles', '08:00', '18:00', 1),
('Jueves', '08:00', '18:00', 1),
('Viernes', '08:00', '18:00', 1),
('Sábado', '07:00', '20:00', 1),
('Domingo', '07:00', '20:00', 1);


INSERT INTO servicios (nombre, descripcion, estado, id_punto_de_alquiler) VALUES
('Alquiler de Bicicletas', 'Alquiler de bicicletas de diferentes tipos', 1, 1),
('Taller de Reparación', 'Servicio de reparación y mantenimiento', 1, 1),
('Venta de Accesorios', 'Venta de cascos, candados y accesorios', 1, 1),
('Alquiler de Bicicletas', 'Bicicletas para playa y ciudad', 1, 2),
('Casilleros', 'Guardado seguro de pertenencias', 1, 2);


INSERT INTO seguro (nombre, numero_de_poliza, aseguradora, fecha_inicio, fecha_fin) VALUES
('Seguro Básico', 'POL-001-2024', 'Seguros Colombia', '2024-01-01', '2025-12-31'),
('Seguro Premium', 'POL-002-2024', 'Seguros Colombia', '2024-01-01', '2025-12-31'),
('Seguro Deportivo', 'POL-003-2024', 'Liberty Seguros', '2024-01-01', '2025-12-31');


INSERT INTO tipo_de_estado_bicicleta (nombre, descripcion) VALUES
('Excelente', 'Bicicleta en perfecto estado'),
('Bueno', 'Bicicleta en buen estado'),
('Requiere Mantenimiento', 'Necesita revisión');


INSERT INTO bicicletas (codigo, marca, modelo, anio_fabricacion, tamanio_marco, tipo_uso, tipo_asistencia, kilometraje, necesita_mantenimiento, tarifa_base, id_punto_de_alquiler, id_tipo_de_estado_bicicleta, id_seguro) VALUES
('BICI-001', 'Trek', 'Marlin 7', 2023, 'M', 'Montaña', 'Convencional', 250.50, 'No', 35000, 1, 1, 2),
('BICI-002', 'Giant', 'Escape 3', 2023, 'L', 'Urbana', 'Convencional', 180.20, 'No', 25000, 1, 1, 1),
('BICI-003', 'Specialized', 'Rockhopper', 2024, 'M', 'Montaña', 'Convencional', 120.00, 'No', 40000, 1, 1, 2),
('BICI-004', 'Giant', 'Simple Seven', 2023, 'M', 'Urbana', 'Convencional', 340.25, 'Sí', 20000, 2, 2, 1),
('BICI-005', 'Trek', 'Verve 2', 2024, 'S', 'Urbana', 'Convencional', 145.00, 'No', 23000, 2, 1, 1),
('BICI-006', 'Trek', 'Domane AL 2', 2024, 'M', 'Ruta', 'Convencional', 110.50, 'No', 52000, 3, 1, 3),
('BICI-007', 'Giant', 'Contend 3', 2023, 'L', 'Ruta', 'Convencional', 245.30, 'No', 45000, 3, 1, 3),
('BICI-008', 'Trek', 'Dual Sport 3', 2024, 'M', 'Urbana', 'Convencional', 155.30, 'No', 35000, 4, 1, 1),
('BICI-009', 'Scott', 'Sub Sport 30', 2024, 'M', 'Urbana', 'Convencional', 88.90, 'No', 28000, 5, 1, 1),
('BICI-010', 'Merida', 'eScultura', 2024, 'M', 'Ruta', 'Eléctrica', 50.00, 'No', 85000, 1, 1, 3);


INSERT INTO usuario (nombre_completo, email, password, telefono, fecha_nacimiento) VALUES
('Admin Principal', 'admin@bicigo.com', 'hash_password_admin', '+57 300 000 0001', '1985-05-15'),
('Roberto Sánchez', 'roberto@bicigo.com', 'hash_password_mod', '+57 302 222 2222', '1988-03-10'),
('Juliana Ospina', 'juliana@gmail.com', 'hash_password_1', '+57 310 444 4444', '1995-06-18'),
('Miguel Torres', 'miguel@hotmail.com', 'hash_password_2', '+57 311 555 5555', '1987-09-25'),
('Carolina Ruiz', 'carolina@yahoo.com', 'hash_password_3', '+57 312 666 6666', '1993-02-14'),
('Andrés Díaz', 'andres@outlook.com', 'hash_password_4', '+57 313 777 7777', '1991-07-08'),
('Natalia Jiménez', 'natalia@gmail.com', 'hash_password_5', '+57 314 888 8888', '1996-12-03'),
('Fernando Castro', 'fernando@gmail.com', 'hash_password_6', '+57 315 999 9999', '1989-04-20');


INSERT INTO administrador (nivel_acceso, id_usuario) VALUES
('SuperAdmin', 1);


INSERT INTO moderador (area_moderacion, id_usuario) VALUES
('Reseñas', 2);


INSERT INTO turista (idioma_preferencia, zona_horaria, id_usuario) VALUES
('Español', 'America/Bogota', 3),
('Español', 'America/Bogota', 4),
('Español', 'America/Bogota', 5),
('Español', 'America/Bogota', 6),
('Español', 'America/Bogota', 7),
('Español', 'America/Bogota', 8);


INSERT INTO fotos (url, descripcion, id_usuario) VALUES
('https://bicigo.com/users/juliana/photo1.jpg', 'Foto de perfil', 3),
('https://bicigo.com/users/miguel/photo1.jpg', 'Foto de perfil', 4);

r
INSERT INTO planes_de_alquiler (nombre, descripcion, estado_plan) VALUES
('Plan Por Hora', 'Ideal para recorridos cortos', 1),
('Plan Por Día', 'Perfecto para todo el día', 1),
('Plan Semanal', 'Una semana de aventuras', 1),
('Plan Mensual', 'Para ciclistas frecuentes', 1);


INSERT INTO duracion (tipo_duracion, cantidad, id_planes_de_alquiler) VALUES
('Hora', 1, 1),
('Día', 1, 2),
('Semana', 1, 3),
('Mes', 1, 4);


INSERT INTO tarifas (monto, moneda, fecha_inicio, fecha_fin, id_duracion) VALUES
(8000, 'COP', '2024-01-01', NULL, 1),
(35000, 'COP', '2024-01-01', NULL, 2),
(180000, 'COP', '2024-01-01', NULL, 3),
(600000, 'COP', '2024-01-01', NULL, 4);


INSERT INTO tipo_de_metodo_de_pago (nombre, descripcion) VALUES
('Tarjeta Visa', 'Tarjetas Visa'),
('Tarjeta Mastercard', 'Tarjetas Mastercard'),
('PayPal', 'Pago con PayPal'),
('Nequi', 'Billetera Nequi'),
('Efectivo', 'Pago en efectivo');


INSERT INTO pago (monto, fecha_pago, estado, id_planes_de_alquiler, id_tipo_pago) VALUES
(35000, '2024-09-15 10:30:00', 'Completado', 2, 1),
(35000, '2024-09-20 14:15:00', 'Completado', 2, 3),
(8000, '2024-09-25 16:20:00', 'Completado', 1, 4),
(180000, '2024-10-01 08:30:00', 'Completado', 3, 1),
(35000, '2024-10-03 15:45:00', 'Completado', 2, 5);

INSERT INTO tipo_de_beneficio (nombre, descripcion) VALUES
('Casco Incluido', 'Casco de protección incluido'),
('Candado Incluido', 'Candado de seguridad'),
('Mapa de Rutas', 'Mapa con rutas recomendadas'),
('Asistencia 24/7', 'Soporte las 24 horas');


INSERT INTO beneficios (nombre, detalle, id_planes_de_alquiler, id_tipo_beneficio) VALUES
('Casco', 'Casco incluido', 1, 1),
('Candado', 'Candado incluido', 1, 2),
('Casco', 'Casco incluido', 2, 1),
('Candado', 'Candado incluido', 2, 2),
('Mapa', 'Mapa de rutas', 2, 3),
('Asistencia', 'Asistencia telefónica', 3, 4);

-- Etiquetas
INSERT INTO etiquetas (nombre, categoria) VALUES
('Excelente Servicio', 'Atención'),
('Muy Recomendado', 'General'),
('Bicicleta Cómoda', 'Equipo'),
('Ruta Escénica', 'Ruta'),
('Para Familias', 'Público');


INSERT INTO historial_de_alquiler (fecha_inicio, fecha_fin, kilometros_recorridos, costo_total, id_usuario, id_bicicletas, id_planes_de_alquiler, id_etiqueta) VALUES
('2024-09-15 11:00:00', '2024-09-15 18:30:00', 25.5, 35000, 3, 1, 2, 1),
('2024-09-20 15:00:00', '2024-09-20 19:45:00', 18.2, 35000, 4, 2, 2, 2),
('2024-09-25 16:30:00', '2024-09-25 18:00:00', 8.3, 8000, 5, 4, 1, NULL),
('2024-10-01 09:00:00', '2024-10-07 18:00:00', 145.8, 180000, 6, 6, 3, 3),
('2024-10-03 16:00:00', '2024-10-03 20:30:00', 15.4, 35000, 7, 2, 2, NULL);


INSERT INTO reseña (titulo, calificacion, descripcion, fecha_creacion, id_usuario, id_etiqueta) VALUES
('Excelente experiencia', 5.0, 'La bicicleta estaba perfecta y el servicio fue excelente', '2024-09-16 10:00:00', 3, 1),
('Muy buena bicicleta', 4.5, 'Todo bien, muy cómoda la bicicleta', '2024-09-21 09:15:00', 4, 2),
('Paseo corto pero bueno', 4.0, 'Buen servicio para paseos cortos', '2024-09-26 10:00:00', 5, NULL),
('Semana fantástica', 5.0, 'Una semana increíble recorriendo la ciudad', '2024-10-08 09:00:00', 6, 3);


INSERT INTO tipo_de_multimedia (nombre, extension, tamaño, hipervinculo) VALUES
('jpg', '.jpg', 10, NULL),
('png', '.png', 10, NULL),
('mp4', '.mp4', 100, NULL);


INSERT INTO multimedia (url, fecha_subida, fecha_aprobacion, id_reseña, id_tipo_de_multimedia) VALUES
('https://bicigo.com/reviews/user3/photo1.jpg', '2024-09-16 10:05:00', '2024-09-16 14:35:00', 1, 1),
('https://bicigo.com/reviews/user3/photo2.jpg', '2024-09-16 10:06:00', '2024-09-16 14:35:00', 1, 1),
('https://bicigo.com/reviews/user6/photo1.jpg', '2024-10-08 09:10:00', '2024-10-08 10:35:00', 4, 1);

