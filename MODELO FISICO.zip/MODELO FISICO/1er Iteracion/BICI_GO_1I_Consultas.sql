


-- TODAS LAS BICICLETAS DISPONIBLES


SELECT 
    b.codigo,
    b.marca,
    b.modelo,
    b.tipo_uso,
    b.tipo_asistencia,
    b.tarifa_base,
    pa.nombre AS punto_alquiler,
    c.nombre AS ciudad
FROM bicicletas b
INNER JOIN punto_de_alquiler pa ON b.id_punto_de_alquiler = pa.id_punto_de_alquiler
INNER JOIN ciudad c ON pa.id_ciudad = c.id_ciudad
ORDER BY b.marca, b.modelo;


-- BICICLETAS POR PUNTO DE ALQUILER


SELECT 
    pa.nombre AS punto_alquiler,
    COUNT(b.id_bicicletas) AS total_bicicletas,
    pa.capacidad_bicicletas,
    pa.capacidad_bicicletas - COUNT(b.id_bicicletas) AS espacios_disponibles
FROM punto_de_alquiler pa
LEFT JOIN bicicletas b ON pa.id_punto_de_alquiler = b.id_punto_de_alquiler
GROUP BY pa.nombre, pa.capacidad_bicicletas
ORDER BY pa.nombre;


-- BICICLETAS QUE NECESITAN MANTENIMIENTO


SELECT 
    b.codigo,
    b.marca,
    b.modelo,
    b.kilometraje,
    b.necesita_mantenimiento,
    eb.nombre AS estado
FROM bicicletas b
INNER JOIN tipo_de_estado_bicicleta eb ON b.id_tipo_de_estado_bicicleta = eb.id_tipo_de_estado_bicicleta
WHERE b.necesita_mantenimiento = 'Sí' OR b.kilometraje > 300
ORDER BY b.kilometraje DESC;



-- PUNTOS DE ALQUILER POR CIUDAD


SELECT 
    c.nombre AS ciudad,
    c.departamento,
    COUNT(pa.id_punto_de_alquiler) AS total_puntos
FROM ciudad c
LEFT JOIN punto_de_alquiler pa ON c.id_ciudad = pa.id_ciudad
GROUP BY c.nombre, c.departamento
ORDER BY total_puntos DESC;


-- SERVICIOS POR PUNTO DE ALQUILER


SELECT 
    pa.nombre AS punto_alquiler,
    s.nombre AS servicio,
    s.descripcion,
    CASE WHEN s.estado = 1 THEN 'Activo' ELSE 'Inactivo' END AS estado
FROM punto_de_alquiler pa
INNER JOIN servicios s ON pa.id_punto_de_alquiler = s.id_punto_de_alquiler
ORDER BY pa.nombre, s.nombre;

-- HORARIOS DE PUNTOS DE ALQUILER


SELECT 
    pa.nombre AS punto_alquiler,
    h.dia_semana,
    h.hora_apertura,
    h.hora_cierre
FROM punto_de_alquiler pa
INNER JOIN horario h ON pa.id_punto_de_alquiler = h.id_punto_de_alquiler
WHERE pa.id_punto_de_alquiler = 1
ORDER BY 
    CASE h.dia_semana
        WHEN 'Lunes' THEN 1
        WHEN 'Martes' THEN 2
        WHEN 'Miércoles' THEN 3
        WHEN 'Jueves' THEN 4
        WHEN 'Viernes' THEN 5
        WHEN 'Sábado' THEN 6
        WHEN 'Domingo' THEN 7
    END;

PRINT '';



-- TODOS LOS USUARIOS POR TIPO


SELECT 
    u.nombre_completo,
    u.email,
    u.telefono,
    CASE 
        WHEN a.id_administrador IS NOT NULL THEN 'Administrador'
        WHEN m.id_moderador IS NOT NULL THEN 'Moderador'
        WHEN t.id_turista IS NOT NULL THEN 'Turista'
        ELSE 'Sin rol'
    END AS tipo_usuario
FROM usuario u
LEFT JOIN administrador a ON u.id_usuario = a.id_usuario
LEFT JOIN moderador m ON u.id_usuario = m.id_usuario
LEFT JOIN turista t ON u.id_usuario = t.id_usuario
ORDER BY tipo_usuario, u.nombre_completo;


-- TURISTAS CON MÁS ALQUILERES


SELECT 
    u.nombre_completo,
    COUNT(h.id_historial) AS total_alquileres,
    SUM(h.costo_total) AS gasto_total,
    AVG(h.kilometros_recorridos) AS km_promedio
FROM usuario u
INNER JOIN turista t ON u.id_usuario = t.id_usuario
LEFT JOIN historial_de_alquiler h ON u.id_usuario = h.id_usuario
GROUP BY u.nombre_completo
ORDER BY total_alquileres DESC;


-- HISTORIAL COMPLETO DE ALQUILERES


SELECT 
    h.id_historial,
    u.nombre_completo AS turista,
    b.codigo AS bicicleta,
    b.marca + ' ' + b.modelo AS modelo_bicicleta,
    p.nombre AS planes,
    h.fecha_inicio,
    h.fecha_fin,
    h.kilometros_recorridos,
    h.costo_total
FROM historial_de_alquiler h
INNER JOIN usuario u ON h.id_usuario = u.id_usuario
INNER JOIN bicicletas b ON h.id_bicicletas = b.id_bicicletas
INNER JOIN planes_de_alquiler p ON h.id_planes_de_alquiler = p.id_planes_de_alquiler
ORDER BY h.fecha_inicio DESC;


-- ALQUILERES POR MES


SELECT 
    FORMAT(h.fecha_inicio, 'yyyy-MM') AS mes,
    COUNT(*) AS total_alquileres,
    SUM(h.costo_total) AS ingresos,
    AVG(h.costo_total) AS ticket_promedio
FROM historial_de_alquiler h
GROUP BY FORMAT(h.fecha_inicio, 'yyyy-MM')
ORDER BY mes DESC;





-- PLANES CON SUS TARIFAS


SELECT 
    p.nombre AS planes,
    p.descripcion,
    d.tipo_duracion,
    d.cantidad,
    t.monto,
    t.moneda,
    CASE WHEN p.estado_plan = 1 THEN 'Activo' ELSE 'Inactivo' END AS estado
FROM planes_de_alquiler p
INNER JOIN duracion d ON p.id_planes_de_alquiler = d.id_planes_de_alquiler
INNER JOIN tarifas t ON d.id_duracion = t.id_duracion
ORDER BY t.monto;


-- BENEFICIOS POR PLAN


SELECT 
    p.nombre AS planes,
    b.nombre AS beneficio,
    b.detalle,
    tb.descripcion AS tipo_beneficio
FROM planes_de_alquiler p
INNER JOIN beneficios b ON p.id_planes_de_alquiler = b.id_planes_de_alquiler
INNER JOIN tipo_de_beneficio tb ON b.id_tipo_beneficio = tb.id_tipo_beneficio
ORDER BY p.nombre, b.nombre;


-- PLAN MÁS POPULAR


SELECT 
    p.nombre AS planes,
    COUNT(h.id_historial) AS veces_usado,
    SUM(h.costo_total) AS ingresos_generados
FROM planes_de_alquiler p
LEFT JOIN historial_de_alquiler h ON p.id_planes_de_alquiler = h.id_planes_de_alquiler
GROUP BY p.nombre
ORDER BY veces_usado DESC;



-- TODAS LAS RESEÑAS CON CALIFICACIÓN


SELECT 
    r.titulo,
    r.calificacion,
    r.descripcion,
    u.nombre_completo AS autor,
    r.fecha_creacion,
    e.nombre AS etiqueta
FROM reseña r
INNER JOIN usuario u ON r.id_usuario = u.id_usuario
LEFT JOIN etiquetas e ON r.id_etiqueta = e.id_etiquetas
ORDER BY r.fecha_creacion DESC;


--CALIFICACIÓN PROMEDIO


SELECT 
    AVG(calificacion) AS calificacion_promedio,
    COUNT(*) AS total_reseñas,
    MAX(calificacion) AS mejor_calificacion,
    MIN(calificacion) AS peor_calificacion
FROM reseña;


-- RESEÑAS CON MULTIMEDIA

SELECT 
    r.titulo,
    r.calificacion,
    u.nombre_completo AS autor,
    COUNT(m.id_multimedia) AS archivos_multimedia
FROM reseña r
INNER JOIN usuario u ON r.id_usuario = u.id_usuario
LEFT JOIN multimedia m ON r.id_reseña = m.id_reseña
GROUP BY r.titulo, r.calificacion, u.nombre_completo
HAVING COUNT(m.id_multimedia) > 0
ORDER BY archivos_multimedia DESC;





-- PAGOS POR MÉTODO

SELECT 
    tmp.nombre AS metodo_pago,
    COUNT(p.id_pago) AS total_transacciones,
    SUM(p.monto) AS monto_total
FROM tipo_de_metodo_de_pago tmp
LEFT JOIN pago p ON tmp.id_tipo_pago = p.id_tipo_pago
GROUP BY tmp.nombre
ORDER BY total_transacciones DESC;


-- PAGOS COMPLETADOS

SELECT 
    p.monto,
    p.fecha_pago,
    p.estado,
    pl.nombre AS planes,
    tmp.nombre AS metodo_pago
FROM pago p
INNER JOIN planes_de_alquiler pl ON p.id_planes_de_alquiler = pl.id_planes_de_alquiler
INNER JOIN tipo_de_metodo_de_pago tmp ON p.id_tipo_pago = tmp.id_tipo_pago
WHERE p.estado = 'Completado'
ORDER BY p.fecha_pago DESC;



-- INGRESOS TOTALES

SELECT 
    SUM(costo_total) AS ingresos_totales,
    AVG(costo_total) AS ingreso_promedio,
    COUNT(*) AS total_alquileres
FROM historial_de_alquiler;

